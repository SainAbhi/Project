import { Router } from "express";

import {
  getBrands,
  createBrand,
} from "../controllers/brand.controller";

import {
  authenticateToken,
  authorizeRoles,
} from "../middleware/auth.middleware";

const router = Router();

// View brands
router.get(
  "/",
  authenticateToken,
  authorizeRoles("Manager", "Inventory Staff"),
  getBrands
);

// Create brand
router.post(
  "/",
  authenticateToken,
  authorizeRoles("Manager", "Inventory Staff"),
  createBrand
);

export default router;

